Langkah Langkah Untuk Membuat Websitenya

1. Pertama Download Script Ini
2. Buka Script Menggunakan Text Editor Apapun
3. Buka Index.Html dan edit nama faresa menjadi nama kalian
4. Buka Script.js untuk mengubah nama sender
5. Buatlah akun github.com
6. Buat new repository dengan nama sesuai nama akun kalian contoh disini nama akun github saya *faresapn* sehingga menjadi **Faresapn.github.io**
7. Upload source code yang telah kalian edit tadi dengan cara klik  add files , lalu upload files yang tadi
8. Selamat Mencoba
